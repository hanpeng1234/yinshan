def aaa():
    print("aaaa")