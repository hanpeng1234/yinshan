def aaa():
    print("bbbbb")